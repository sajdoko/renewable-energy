<?php
/*
Plugin Name: Renewable Energy CPT
Plugin URI: https://github.com/sajdoko/renewable-energy
Description: Adds the Slides Post Type + Projects Post Type with te 'type' taxonomy
Author: Sajmir Doko
Version: 1.0.0
Author URI: https://www.linkedin.com/in/sajmirdoko
 */

// Create Slides Post Type
function register_slides_posttype_init() {
    /**
     * add the projects custom post type
     * https://codex.wordpress.org/Function_Reference/register_post_type
     */
    $labels = array(
        'name' => _x('Slides', 'post type general name', 'renewable-energy'),
        'singular_name' => _x('Slide', 'post type singular name', 'renewable-energy'),
        'add_new' => __('Add New Slide', 'renewable-energy'),
        'add_new_item' => __('Add New Slide', 'renewable-energy'),
        'edit_item' => __('Edit Slide', 'renewable-energy'),
        'new_item' => __('New Slide', 'renewable-energy'),
        'view_item' => __('View Slide', 'renewable-energy'),
        'search_items' => __('Search Slides', 'renewable-energy'),
        'not_found' => __('Slide', 'renewable-energy'),
        'not_found_in_trash' => __('Slide', 'renewable-energy'),
        'parent_item_colon' => __('Slide', 'renewable-energy'),
        'menu_name' => __('Slides', 'renewable-energy'),
    );

    $taxonomies = array();

    $supports = array('editor', 'title', 'thumbnail');

    $post_type_args = array(
        'labels' => $labels,
        'singular_label' => _x('Slide', 'post type singular label', 'renewable-energy'),
        'public' => true,
        'show_ui' => true,
        'publicly_queryable' => true,
        'query_var' => true,
        'capability_type' => 'post',
        'has_archive' => false,
        'hierarchical' => false,
        'rewrite' => array('slug' => 'slides', 'with_front' => false),
        'supports' => $supports,
        'menu_position' => 7, // Where it is in the menu. Change to 6 and it's below posts. 11 and it's below media, etc.
        'menu_icon' => 'dashicons-image-flip-horizontal',
        'taxonomies' => $taxonomies,
    );
    register_post_type('slides', $post_type_args);
}
add_action('init', 'register_slides_posttype_init');

// Create Projects Post Type
function register_projects_posttype_init() {
    /**
     * add the projects custom post type
     * https://codex.wordpress.org/Function_Reference/register_post_type
     */
    $labels = array(
        'name' => _x('Projects', 'post type general name', 'renewable-energy'),
        'singular_name' => _x('Project', 'post type singular name', 'renewable-energy'),
        'add_new' => __('Add New Project', 'renewable-energy'),
        'add_new_item' => __('Add New Project', 'renewable-energy'),
        'edit_item' => __('Edit Project', 'renewable-energy'),
        'new_item' => __('New Project', 'renewable-energy'),
        'view_item' => __('View Project', 'renewable-energy'),
        'search_items' => __('Search Projects', 'renewable-energy'),
        'not_found' => __('Project', 'renewable-energy'),
        'not_found_in_trash' => __('Project', 'renewable-energy'),
        'parent_item_colon' => __('Project', 'renewable-energy'),
        'menu_name' => __('Projects', 'renewable-energy'),
    );

    $taxonomies = array();

    $supports = array(
        'title',
        'editor',
        'thumbnail',
        'excerpt',
    );

    $post_type_args = array(
        'labels' => $labels,
        'singular_label' => _x('Project', 'post type singular label', 'renewable-energy'),
        'public' => true,
        'show_ui' => true,
        'publicly_queryable' => true,
        'query_var' => true,
        'capability_type' => 'post',
        'has_archive' => true,
        'hierarchical' => true,
        'rewrite' => array('slug' => 'projects', 'with_front' => false),
        'supports' => $supports,
        'menu_position' => 6, // Where it is in the menu. Change to 6 and it's below posts. 11 and it's below media, etc.
        'menu_icon' => 'dashicons-portfolio',
        'taxonomies' => $taxonomies,
    );
    register_post_type('projects', $post_type_args);

    /**
     * Add new taxonomy, type, make it hierarchical (like categories) and associate it to the projects Custom Post Type
     * https://codex.wordpress.org/Function_Reference/register_taxonomy
     */
    $labels = array(
        'name' => _x('Types', 'taxonomy general name', 'renewable-energy'),
        'singular_name' => _x('Type', 'taxonomy singular name', 'renewable-energy'),
        'search_items' => __('Search Types', 'renewable-energy'),
        'all_items' => __('All Types', 'renewable-energy'),
        'parent_item' => __('Parent Type', 'renewable-energy'),
        'parent_item_colon' => __('Parent Type:', 'renewable-energy'),
        'edit_item' => __('Edit Type', 'renewable-energy'),
        'update_item' => __('Update Type', 'renewable-energy'),
        'add_new_item' => __('Add New Type', 'renewable-energy'),
        'new_item_name' => __('New Type Name', 'renewable-energy'),
        'menu_name' => __('Type', 'renewable-energy'),
    );

    $args = array(
        'hierarchical' => true,
        'labels' => $labels,
        'show_ui' => true,
        'show_admin_column' => true,
        'query_var' => true,
        'rewrite' => array('slug' => 'type'),
    );

    register_taxonomy('type', array('projects'), $args);

}
add_action('init', 'register_projects_posttype_init');

/**
 * this hook will regenerate the permalinks when the plugin is activated.
 */
function renewable_energy_regenerate_htaccess() {
    register_projects_posttype_init();
    flush_rewrite_rules();
}
register_activation_hook(__FILE__, 'renewable_energy_regenerate_htaccess');

if (!function_exists('renewable_energy_tiny_mce_style_formats')) {
// Add TinyMCE style formats.
    function renewable_energy_tiny_mce_style_formats($styles) {
        array_unshift($styles, 'styleselect');
        return $styles;
    }
    add_filter('mce_buttons_2', 'renewable_energy_tiny_mce_style_formats');
}
if (!function_exists('renewable_energy_tiny_mce_before_init')) {
    function renewable_energy_tiny_mce_before_init($settings) {

        $style_formats = array(
            array(
                'title' => 'Lead Paragraph',
                'selector' => 'p',
                'classes' => 'lead',
                'wrapper' => true,
            ),
            array(
                'title' => 'Small',
                'inline' => 'small',
            ),
            array(
                'title' => 'Blockquote',
                'block' => 'blockquote',
                'classes' => 'blockquote',
                'wrapper' => true,
            ),
            array(
                'title' => 'Blockquote Footer',
                'block' => 'footer',
                'classes' => 'blockquote-footer',
                'wrapper' => true,
            ),
            array(
                'title' => 'Cite',
                'inline' => 'cite',
            ),
        );
        if (isset($settings['style_formats'])) {
            $orig_style_formats = json_decode($settings['style_formats'], true);
            $style_formats = array_merge($orig_style_formats, $style_formats);
        }
        $settings['style_formats'] = json_encode($style_formats);
        return $settings;
    }
    add_filter('tiny_mce_before_init', 'renewable_energy_tiny_mce_before_init');
}